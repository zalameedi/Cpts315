#!/bin/sh
# Zeid Al-Ameedi 11484180
# In my case py is an environment variable on windows10 as python3

py HW2.py


function pause(){
   read -p "$*"
}
 
pause 'Press [Enter] key to continue...'