#!/bin/sh

python3 PA1.py