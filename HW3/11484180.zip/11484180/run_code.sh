#! /bin/sh
py ./HW3.py